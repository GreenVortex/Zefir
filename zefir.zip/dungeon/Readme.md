<h1 align='center'>Welcome to Dungeons and Dice👋</h1>

> A dice rolling utility for role playing games.

This project was made with Javascript💻

## Version
3.0

## Install
```sh
Project does not require an installation
```

## Usage
```sh
No usage documentation required
```

## Author

👤 **Jan Andersson**

## Show your support

Give a ⭐️ if this project helped you!

Readme created with ❤️ using [NESS](https://github.com/GreenVortex/NESS)
