//Function for Generating dice number
function NumGen() {
  document.getElementById("GenNum").innerHTML = Math.floor(Math.random() * DiceNumber) + 1;
   }
